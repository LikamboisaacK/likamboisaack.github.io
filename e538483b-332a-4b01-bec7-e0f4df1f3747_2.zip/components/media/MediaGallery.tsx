'use client';

import { useState } from 'react';

interface MediaGalleryProps {
  filter?: string;
}

export default function MediaGallery({ filter }: MediaGalleryProps) {
  const [mediaItems] = useState([
    {
      id: 1,
      type: 'photo',
      title: 'Traditional Keliko Dance Performance',
      author: 'Sarah Kiden',
      thumbnail: 'https://readdy.ai/api/search-image?query=Traditional%20African%20dance%20performance%20young%20people%20colorful%20traditional%20clothing%20cultural%20celebration%20outdoor%20setting%20community%20gathering%20South%20Sudan%20Uganda%20Keliko%20traditions&width=400&height=300&seq=media-1&orientation=landscape',
      likes: 34,
      views: 156,
      uploadDate: '2 days ago'
    },
    {
      id: 2,
      type: 'video',
      title: 'Youth Peace Dialogue Session',
      author: 'James Loku',
      thumbnail: 'https://readdy.ai/api/search-image?query=Young%20people%20sitting%20in%20circle%20community%20discussion%20dialogue%20session%20outdoor%20setting%20peaceful%20meeting%20refugee%20settlement%20Uganda%20South%20Sudan%20youth%20empowerment&width=400&height=300&seq=media-2&orientation=landscape',
      likes: 42,
      views: 289,
      duration: '12:34',
      uploadDate: '3 days ago'
    },
    {
      id: 3,
      type: 'audio',
      title: 'Traditional Úngó Songs Collection',
      author: 'Grace Amara',
      thumbnail: 'https://readdy.ai/api/search-image?query=Traditional%20African%20musical%20instruments%20drum%20traditional%20music%20audio%20recording%20cultural%20preservation%20South%20Sudan%20Uganda%20Keliko%20music%20heritage&width=400&height=300&seq=media-3&orientation=landscape',
      likes: 28,
      views: 178,
      duration: '8:45',
      uploadDate: '5 days ago'
    },
    {
      id: 4,
      type: 'video',
      title: 'Gender Equality Workshop Drama',
      author: 'Peter Wani',
      thumbnail: 'https://readdy.ai/api/search-image?query=Community%20theater%20performance%20young%20African%20actors%20drama%20workshop%20educational%20performance%20gender%20equality%20awareness%20refugee%20settlement%20Uganda%20South%20Sudan&width=400&height=300&seq=media-4&orientation=landscape',
      likes: 57,
      views: 324,
      duration: '15:23',
      uploadDate: '1 week ago'
    },
    {
      id: 5,
      type: 'photo',
      title: 'Cultural Heritage Exhibition',
      author: 'Rebecca Lado',
      thumbnail: 'https://readdy.ai/api/search-image?query=Cultural%20heritage%20exhibition%20traditional%20artifacts%20handcrafts%20display%20African%20cultural%20items%20colorful%20traditional%20crafts%20South%20Sudan%20Uganda%20Keliko%20heritage%20preservation&width=400&height=300&seq=media-5&orientation=landscape',
      likes: 39,
      views: 203,
      uploadDate: '1 week ago'
    },
    {
      id: 6,
      type: 'audio',
      title: 'Community Stories Podcast',
      author: 'David Konga',
      thumbnail: 'https://readdy.ai/api/search-image?query=Podcast%20recording%20setup%20microphone%20audio%20equipment%20storytelling%20community%20voices%20African%20youth%20sharing%20stories%20South%20Sudan%20Uganda%20refugee%20settlement%20community%20media&width=400&height=300&seq=media-6&orientation=landscape',
      likes: 31,
      views: 145,
      duration: '25:12',
      uploadDate: '2 weeks ago'
    }
  ]);

  const filteredItems = filter === 'photos' 
    ? mediaItems.filter(item => item.type === 'photo')
    : mediaItems;

  const [selectedItem, setSelectedItem] = useState(null);

  return (
    <div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map(item => (
          <div key={item.id} className="bg-white rounded-lg shadow-sm overflow-hidden group">
            <div className="relative">
              <img 
                src={item.thumbnail} 
                alt={item.title}
                className="w-full h-48 object-cover object-top"
              />
              
              {item.type === 'video' && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center cursor-pointer">
                    <i className="ri-play-fill text-2xl text-gray-800"></i>
                  </div>
                </div>
              )}
              
              {item.type === 'audio' && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center cursor-pointer">
                    <i className="ri-play-fill text-2xl text-gray-800"></i>
                  </div>
                </div>
              )}
              
              <div className="absolute top-3 left-3">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  item.type === 'photo' ? 'bg-green-600 text-white' :
                  item.type === 'video' ? 'bg-blue-600 text-white' :
                  'bg-purple-600 text-white'
                }`}>
                  {item.type === 'photo' ? 'Photo' : 
                   item.type === 'video' ? 'Video' : 'Audio'}
                </span>
              </div>
              
              {item.duration && (
                <div className="absolute bottom-3 right-3 bg-black/70 text-white px-2 py-1 rounded text-xs">
                  {item.duration}
                </div>
              )}
            </div>
            
            <div className="p-4">
              <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">{item.title}</h3>
              <p className="text-sm text-gray-600 mb-3">by {item.author}</p>
              
              <div className="flex items-center justify-between text-sm text-gray-500">
                <div className="flex items-center space-x-4">
                  <span className="flex items-center space-x-1">
                    <i className="ri-heart-line"></i>
                    <span>{item.likes}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <i className="ri-eye-line"></i>
                    <span>{item.views}</span>
                  </span>
                </div>
                <span>{item.uploadDate}</span>
              </div>
              
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                <button className="flex items-center space-x-2 text-gray-600 hover:text-red-600 transition-colors cursor-pointer">
                  <i className="ri-heart-line"></i>
                  <span className="text-sm">Like</span>
                </button>
                <button className="flex items-center space-x-2 text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                  <i className="ri-share-line"></i>
                  <span className="text-sm">Share</span>
                </button>
                <button className="flex items-center space-x-2 text-gray-600 hover:text-green-600 transition-colors cursor-pointer">
                  <i className="ri-download-line"></i>
                  <span className="text-sm">Save</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {filteredItems.length === 0 && (
        <div className="text-center py-12">
          <i className="ri-image-line text-4xl text-gray-300 mb-4"></i>
          <p className="text-gray-500">No media content found.</p>
        </div>
      )}
    </div>
  );
}