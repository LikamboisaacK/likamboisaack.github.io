'use client';

import { useState } from 'react';

export default function VideoPlayer() {
  const [videos] = useState([
    {
      id: 1,
      title: 'Youth Peace Dialogue Session',
      author: 'James Loku',
      duration: '12:34',
      views: 289,
      likes: 42,
      thumbnail: 'https://readdy.ai/api/search-image?query=Young%20people%20sitting%20in%20circle%20community%20discussion%20dialogue%20session%20outdoor%20setting%20peaceful%20meeting%20refugee%20settlement%20Uganda%20South%20Sudan%20youth%20empowerment%20discussion&width=800&height=450&seq=video-1&orientation=landscape',
      description: 'A powerful dialogue session where youth from different communities come together to discuss peace, understanding, and unity. This session demonstrates the impact of youth-led peacebuilding initiatives.',
      uploadDate: '3 days ago'
    },
    {
      id: 2,
      title: 'Gender Equality Workshop Drama',
      author: 'Peter Wani',
      duration: '15:23',
      views: 324,
      likes: 57,
      thumbnail: 'https://readdy.ai/api/search-image?query=Community%20theater%20performance%20young%20African%20actors%20drama%20workshop%20educational%20performance%20gender%20equality%20awareness%20refugee%20settlement%20Uganda%20South%20Sudan%20community%20engagement&width=800&height=450&seq=video-2&orientation=landscape',
      description: 'An impactful drama performance addressing gender-based violence and promoting gender equality. Our creative arts team uses theater to educate and inspire positive change in our community.',
      uploadDate: '1 week ago'
    },
    {
      id: 3,
      title: 'Traditional Dance Workshop',
      author: 'Sarah Kiden',
      duration: '18:45',
      views: 456,
      likes: 78,
      thumbnail: 'https://readdy.ai/api/search-image?query=Traditional%20African%20dance%20workshop%20young%20people%20learning%20cultural%20dance%20colorful%20traditional%20clothing%20outdoor%20setting%20community%20cultural%20preservation%20South%20Sudan%20Uganda&width=800&height=450&seq=video-3&orientation=landscape',
      description: 'Teaching traditional Keliko dances to the younger generation. This workshop showcases the beauty of our cultural heritage and the importance of passing traditions to future generations.',
      uploadDate: '2 weeks ago'
    }
  ]);

  const [selectedVideo, setSelectedVideo] = useState(videos[0]);

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="relative">
            <img 
              src={selectedVideo.thumbnail}
              alt={selectedVideo.title}
              className="w-full h-64 md:h-96 object-cover object-top"
            />
            <div className="absolute inset-0 flex items-center justify-center bg-black/20">
              <div className="w-20 h-20 bg-white/90 rounded-full flex items-center justify-center cursor-pointer hover:bg-white transition-colors">
                <i className="ri-play-fill text-3xl text-gray-800 ml-1"></i>
              </div>
            </div>
            <div className="absolute bottom-4 right-4 bg-black/70 text-white px-2 py-1 rounded text-sm">
              {selectedVideo.duration}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h1 className="text-xl md:text-2xl font-bold text-gray-900 mb-3">
            {selectedVideo.title}
          </h1>
          
          <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
            <div className="flex items-center space-x-4 text-gray-600">
              <span className="flex items-center space-x-1">
                <i className="ri-eye-line"></i>
                <span>{selectedVideo.views} views</span>
              </span>
              <span>{selectedVideo.uploadDate}</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <button className="flex items-center space-x-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap">
                <i className="ri-heart-line"></i>
                <span>{selectedVideo.likes}</span>
              </button>
              <button className="flex items-center space-x-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer">
                <i className="ri-share-line"></i>
              </button>
              <button className="flex items-center space-x-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors cursor-pointer">
                <i className="ri-download-line"></i>
              </button>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 mb-4 p-4 bg-gray-50 rounded-lg">
            <div className="w-12 h-12 bg-gray-300 rounded-full"></div>
            <div>
              <p className="font-medium text-gray-900">{selectedVideo.author}</p>
              <p className="text-sm text-gray-600">KYN Member</p>
            </div>
            <button className="ml-auto bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap">
              Follow
            </button>
          </div>
          
          <div className="border-t border-gray-100 pt-4">
            <h3 className="font-medium text-gray-900 mb-2">About this video</h3>
            <p className="text-gray-600 leading-relaxed">{selectedVideo.description}</p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-sm">
          <div className="p-4 border-b border-gray-100">
            <h3 className="font-bold text-gray-900">More Videos</h3>
          </div>
          
          <div className="divide-y divide-gray-100">
            {videos.filter(v => v.id !== selectedVideo.id).map(video => (
              <div 
                key={video.id}
                onClick={() => setSelectedVideo(video)}
                className="p-4 hover:bg-gray-50 cursor-pointer transition-colors"
              >
                <div className="flex space-x-3">
                  <div className="w-32 h-20 flex-shrink-0 relative">
                    <img 
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-full object-cover rounded object-top"
                    />
                    <div className="absolute bottom-1 right-1 bg-black/70 text-white px-1 py-0.5 rounded text-xs">
                      {video.duration}
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-gray-900 mb-1 line-clamp-2">
                      {video.title}
                    </h4>
                    <p className="text-sm text-gray-600 mb-1">{video.author}</p>
                    <div className="flex items-center space-x-3 text-xs text-gray-500">
                      <span>{video.views} views</span>
                      <span>{video.uploadDate}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-4">
          <h3 className="font-bold text-gray-900 mb-4">Comments</h3>
          
          <div className="space-y-4">
            <div className="flex space-x-3">
              <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Add a comment..."
                  className="w-full p-2 border border-gray-200 rounded-lg text-sm"
                />
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex space-x-3">
                <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                <div>
                  <p className="font-medium text-sm text-gray-900">Mary Johnson</p>
                  <p className="text-sm text-gray-600">This is such important work! Thank you for sharing these stories.</p>
                  <div className="flex items-center space-x-3 mt-1">
                    <span className="text-xs text-gray-500">2 hours ago</span>
                    <button className="text-xs text-gray-500 hover:text-green-600 cursor-pointer">Like</button>
                    <button className="text-xs text-gray-500 hover:text-green-600 cursor-pointer">Reply</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}