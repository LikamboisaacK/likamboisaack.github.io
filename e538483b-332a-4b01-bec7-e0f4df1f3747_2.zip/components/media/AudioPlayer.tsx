'use client';

import { useState } from 'react';

export default function AudioPlayer() {
  const [currentTrack, setCurrentTrack] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  
  const audioTracks = [
    {
      id: 1,
      title: 'Traditional Úngó Songs Collection',
      artist: 'Grace Amara & Community Elders',
      duration: '8:45',
      thumbnail: 'https://readdy.ai/api/search-image?query=Traditional%20African%20musical%20instruments%20drum%20traditional%20music%20cultural%20preservation%20South%20Sudan%20Uganda%20Keliko%20music%20heritage%20community%20singing&width=300&height=300&seq=audio-1&orientation=squarish',
      description: 'A collection of traditional Keliko songs passed down through generations.'
    },
    {
      id: 2,
      title: 'Youth Stories Podcast - Episode 1',
      artist: 'David Konga',
      duration: '25:12',
      thumbnail: 'https://readdy.ai/api/search-image?query=Podcast%20recording%20setup%20microphone%20audio%20equipment%20storytelling%20young%20African%20man%20South%20Sudan%20Uganda%20refugee%20settlement%20community%20voices&width=300&height=300&seq=audio-2&orientation=squarish',
      description: 'Personal stories of resilience and hope from Keliko youth in displacement.'
    },
    {
      id: 3,
      title: 'Peace Songs for Unity',
      artist: 'KYN Peace Choir',
      duration: '12:30',
      thumbnail: 'https://readdy.ai/api/search-image?query=African%20youth%20choir%20singing%20together%20peace%20songs%20community%20harmony%20traditional%20and%20modern%20music%20blend%20South%20Sudan%20Uganda%20cultural%20unity&width=300&height=300&seq=audio-3&orientation=squarish',
      description: 'Original compositions promoting peace and unity among communities.'
    },
    {
      id: 4,
      title: 'Cultural Language Lessons',
      artist: 'Sarah Kiden',
      duration: '15:20',
      thumbnail: 'https://readdy.ai/api/search-image?query=Language%20teaching%20session%20young%20African%20woman%20teaching%20traditional%20language%20cultural%20education%20community%20learning%20South%20Sudan%20Uganda%20heritage%20preservation&width=300&height=300&seq=audio-4&orientation=squarish',
      description: 'Learn basic Keliko phrases and understand cultural contexts.'
    }
  ];

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="w-48 h-48 flex-shrink-0">
            <img 
              src={audioTracks[currentTrack].thumbnail}
              alt={audioTracks[currentTrack].title}
              className="w-full h-full object-cover rounded-lg shadow-md object-top"
            />
          </div>
          
          <div className="flex-1 text-center md:text-left">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              {audioTracks[currentTrack].title}
            </h2>
            <p className="text-lg text-gray-600 mb-4">
              {audioTracks[currentTrack].artist}
            </p>
            <p className="text-gray-500 mb-6 leading-relaxed">
              {audioTracks[currentTrack].description}
            </p>
            
            <div className="bg-gray-200 h-2 rounded-full mb-4">
              <div className="bg-green-600 h-2 rounded-full w-1/3"></div>
            </div>
            
            <div className="flex items-center justify-between text-sm text-gray-500 mb-6">
              <span>2:35</span>
              <span>{audioTracks[currentTrack].duration}</span>
            </div>
            
            <div className="flex items-center justify-center space-x-4">
              <button className="w-12 h-12 flex items-center justify-center text-gray-600 hover:text-green-600 transition-colors cursor-pointer">
                <i className="ri-skip-back-line text-xl"></i>
              </button>
              
              <button 
                onClick={handlePlayPause}
                className="w-16 h-16 bg-green-600 hover:bg-green-700 text-white rounded-full flex items-center justify-center transition-colors cursor-pointer"
              >
                <i className={`${isPlaying ? 'ri-pause-fill' : 'ri-play-fill'} text-2xl`}></i>
              </button>
              
              <button className="w-12 h-12 flex items-center justify-center text-gray-600 hover:text-green-600 transition-colors cursor-pointer">
                <i className="ri-skip-forward-line text-xl"></i>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-6 border-b border-gray-100">
          <h3 className="text-lg font-bold text-gray-900">Playlist</h3>
        </div>
        
        <div className="divide-y divide-gray-100">
          {audioTracks.map((track, index) => (
            <div 
              key={track.id}
              onClick={() => setCurrentTrack(index)}
              className={`p-4 hover:bg-gray-50 cursor-pointer transition-colors ${
                currentTrack === index ? 'bg-green-50' : ''
              }`}
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 flex-shrink-0">
                  <img 
                    src={track.thumbnail}
                    alt={track.title}
                    className="w-full h-full object-cover rounded object-top"
                  />
                </div>
                
                <div className="flex-1 min-w-0">
                  <h4 className={`font-medium truncate ${
                    currentTrack === index ? 'text-green-600' : 'text-gray-900'
                  }`}>
                    {track.title}
                  </h4>
                  <p className="text-sm text-gray-500 truncate">{track.artist}</p>
                </div>
                
                <div className="text-sm text-gray-500">
                  {track.duration}
                </div>
                
                {currentTrack === index && (
                  <div className="w-6 h-6 flex items-center justify-center">
                    <div className="w-4 h-4 bg-green-600 rounded-full animate-pulse"></div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}