'use client';

import { useState } from 'react';

export default function WhatsAppChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');

  const handleWhatsAppClick = () => {
    const phoneNumber = '256774652401';
    const defaultMessage = 'Hello KYN! I would like to learn more about joining the Keliko Youth Network.';
    const finalMessage = message.trim() || defaultMessage;
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(finalMessage)}`;
    window.open(whatsappUrl, '_blank');
    setIsOpen(false);
    setMessage('');
  };

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">Contact KYN via WhatsApp</h3>
              <button 
                onClick={() => setIsOpen(false)}
                className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 cursor-pointer"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            
            <div className="flex items-center mb-4 p-3 bg-gray-50 rounded-lg">
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mr-3">
                <i className="ri-whatsapp-line text-white text-xl"></i>
              </div>
              <div>
                <p className="font-semibold text-gray-900">KYN Support</p>
                <p className="text-sm text-gray-600">+256 774 652 401</p>
              </div>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Your Message (optional)</label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Hello KYN! I would like to learn more about joining the Keliko Youth Network."
                className="w-full p-3 border border-gray-300 rounded-lg resize-none h-24 text-sm"
                maxLength={500}
              />
              <p className="text-xs text-gray-500 mt-1">{message.length}/500 characters</p>
            </div>
            
            <button 
              onClick={handleWhatsAppClick}
              className="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-semibold transition-colors flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-whatsapp-line text-xl"></i>
              Open WhatsApp
            </button>
          </div>
        </div>
      )}

      <div className="fixed bottom-6 right-6 z-40">
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-green-500 hover:bg-green-600 text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center transition-all duration-300 hover:scale-110 cursor-pointer"
        >
          <i className="ri-whatsapp-line text-2xl"></i>
        </button>
      </div>
    </>
  );
}