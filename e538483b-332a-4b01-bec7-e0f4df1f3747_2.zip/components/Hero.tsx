'use client';

export default function Hero() {
  return (
    <section 
      className="relative min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url('https://readdy.ai/api/search-image?query=African%20youth%20community%20gathering%20in%20refugee%20settlement%2C%20young%20people%20sitting%20in%20circle%20discussing%2C%20traditional%20meeting%20under%20acacia%20tree%2C%20warm%20golden%20sunset%20lighting%2C%20community%20empowerment%2C%20cultural%20diversity%2C%20hope%20and%20unity%2C%20documentary%20photography%20style%2C%20natural%20outdoor%20setting%20in%20Uganda%20landscape&width=1400&height=800&seq=kyn-hero-1&orientation=landscape')`
      }}
    >
      <div className="container mx-auto px-4 text-center text-white">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Keliko Youth Network
          </h1>
          <p className="text-xl md:text-2xl mb-8 opacity-95">
            "Youth Empowerment through Culture, Dialogue, and Action"
          </p>
          <p className="text-lg mb-12 max-w-2xl mx-auto opacity-90">
            Empowering young people as agents of change in humanitarian settings through cultural preservation, peacebuilding, and youth-led development.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
              Join Our Network
            </button>
            <button className="border-2 border-white hover:bg-white hover:text-gray-900 text-white px-8 py-4 rounded-full text-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
              Learn More
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}