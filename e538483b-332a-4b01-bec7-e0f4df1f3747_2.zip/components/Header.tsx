'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b border-gray-100">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
              <i className="ri-community-line text-white text-xl"></i>
            </div>
            <div>
              <h1 className="font-['Pacifico'] text-xl text-green-700">KYN</h1>
              <p className="text-xs text-gray-600">Youth Network</p>
            </div>
          </Link>
          
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="text-gray-700 hover:text-green-600 transition-colors">Home</Link>
            <Link href="/about" className="text-gray-700 hover:text-green-600 transition-colors">About</Link>
            <Link href="/community" className="text-gray-700 hover:text-green-600 transition-colors">Community</Link>
            <Link href="/media" className="text-gray-700 hover:text-green-600 transition-colors">Media Hub</Link>
            <Link href="/contact" className="text-gray-700 hover:text-green-600 transition-colors">Contact</Link>
            <Link href="/login" className="bg-green-600 text-white px-4 py-2 rounded-full hover:bg-green-700 transition-colors whitespace-nowrap cursor-pointer">Join Network</Link>
          </nav>

          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden w-8 h-8 flex items-center justify-center cursor-pointer"
          >
            <i className={`${isMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-xl text-gray-700`}></i>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-gray-100 pt-4">
            <nav className="flex flex-col space-y-3">
              <Link href="/" className="text-gray-700 hover:text-green-600 transition-colors">Home</Link>
              <Link href="/about" className="text-gray-700 hover:text-green-600 transition-colors">About</Link>
              <Link href="/community" className="text-gray-700 hover:text-green-600 transition-colors">Community</Link>
              <Link href="/media" className="text-gray-700 hover:text-green-600 transition-colors">Media Hub</Link>
              <Link href="/contact" className="text-gray-700 hover:text-green-600 transition-colors">Contact</Link>
              <Link href="/login" className="bg-green-600 text-white px-4 py-2 rounded-full hover:bg-green-700 transition-colors text-center whitespace-nowrap cursor-pointer">Join Network</Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}