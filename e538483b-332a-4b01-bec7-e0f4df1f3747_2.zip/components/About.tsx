'use client';

export default function About() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Who We Are</h2>
            <div className="w-24 h-1 bg-green-600 mx-auto mb-8"></div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                The Keliko Youth Network (KYN) is a youth-led community Network formed by members of the Keliko ethnic group living within and in displacement, particularly within the Bidibidi, Imvepi, Rhino Camp Refugee Settlement in Uganda and the diaspora.
              </p>
              <p className="text-lg text-gray-700 mb-8 leading-relaxed">
                KYN serves as a platform for cultural preservation, peacebuilding, and youth-led development, aiming to empower young people as agents of change in humanitarian settings.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
                    <i className="ri-eye-line text-green-600 text-xl"></i>
                  </div>
                  <h3 className="font-bold text-gray-900 mb-3">Vision</h3>
                  <p className="text-gray-600 text-sm">
                    To nurture a generation of empowered Keliko youth championing peace, cultural identity, and sustainable community transformation.
                  </p>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
                    <i className="ri-target-line text-green-600 text-xl"></i>
                  </div>
                  <h3 className="font-bold text-gray-900 mb-3">Mission</h3>
                  <p className="text-gray-600 text-sm">
                    To mobilize, equip, and engage Keliko youth through creative arts, dialogue, education, and leadership development.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=Young%20African%20people%20in%20traditional%20cultural%20dress%20performing%20traditional%20dance%2C%20colorful%20traditional%20clothing%2C%20cultural%20preservation%2C%20community%20celebration%2C%20outdoor%20setting%2C%20joyful%20expressions%2C%20authentic%20African%20cultural%20heritage%2C%20documentary%20photography%20style%2C%20golden%20hour%20lighting&width=600&height=400&seq=kyn-culture-1&orientation=landscape"
                alt="Cultural Performance"
                className="w-full h-auto rounded-lg shadow-lg object-top"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-map-pin-line text-green-600 text-2xl"></i>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Location</h3>
              <p className="text-gray-600">Bidibidi Refugee Settlement, Uganda</p>
              <p className="text-gray-600">Morobo County Central Equatoria State</p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-phone-line text-green-600 text-2xl"></i>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Contact</h3>
              <p className="text-gray-600">+256 774 652 401</p>
              <p className="text-gray-600 text-sm">kynetwork.morobo@gmail.com</p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-group-line text-green-600 text-2xl"></i>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Target Group</h3>
              <p className="text-gray-600">Keliko youth aged 12–35 years</p>
              <p className="text-gray-600 text-sm">Refugee & host communities</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}