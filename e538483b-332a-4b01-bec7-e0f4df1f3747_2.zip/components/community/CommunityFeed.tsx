'use client';

import { useState } from 'react';
import PostCard from './PostCard';

export default function CommunityFeed() {
  const [posts] = useState([
    {
      id: 1,
      author: 'Sarah Kiden',
      avatar: 'https://readdy.ai/api/search-image?query=Young%20African%20woman%20smiling%20portrait%20professional%20headshot%20natural%20lighting%20confident%20expression%20traditional%20cultural%20clothing%20colorful%20background%20South%20Sudan%20Uganda&width=100&height=100&seq=profile-1&orientation=squarish',
      time: '2 hours ago',
      content: 'Just finished leading a cultural preservation workshop teaching traditional Keliko songs to the younger generation. The energy and enthusiasm from our youth is incredible! 🎵 #KYN #CulturalPreservation',
      image: 'https://readdy.ai/api/search-image?query=Young%20African%20people%20learning%20traditional%20music%20sitting%20in%20circle%20outdoors%20cultural%20workshop%20musical%20instruments%20traditional%20songs%20teaching%20learning%20community%20gathering&width=500&height=300&seq=workshop-1&orientation=landscape',
      likes: 24,
      comments: 8,
      shares: 3
    },
    {
      id: 2,
      author: 'James Loku',
      avatar: 'https://readdy.ai/api/search-image?query=Young%20African%20man%20smiling%20portrait%20professional%20headshot%20natural%20lighting%20confident%20expression%20casual%20clothing%20warm%20background%20South%20Sudan%20Uganda&width=100&height=100&seq=profile-2&orientation=squarish',
      time: '5 hours ago',
      content: 'Our peacebuilding dialogue session brought together youth from different communities. Amazing to see how art and music can bridge differences and create understanding. Peace starts with us! ✊',
      likes: 31,
      comments: 12,
      shares: 7
    },
    {
      id: 3,
      author: 'Grace Amara',
      avatar: 'https://readdy.ai/api/search-image?query=Young%20African%20woman%20confident%20expression%20portrait%20professional%20headshot%20natural%20lighting%20bright%20smile%20traditional%20elements%20modern%20style%20South%20Sudan%20Uganda&width=100&height=100&seq=profile-3&orientation=squarish',
      time: '1 day ago',
      content: 'Excited to announce our upcoming youth leadership training program! Applications are now open for all KYN members aged 18-35. This is your chance to develop skills and make a real impact in our community. Link in bio! 🚀',
      likes: 45,
      comments: 18,
      shares: 15
    },
    {
      id: 4,
      author: 'Peter Wani',
      avatar: 'https://readdy.ai/api/search-image?query=Young%20African%20man%20serious%20expression%20portrait%20professional%20headshot%20natural%20lighting%20determined%20look%20casual%20clothing%20warm%20background%20South%20Sudan%20Uganda&width=100&height=100&seq=profile-4&orientation=squarish',
      time: '2 days ago',
      content: 'Sharing some highlights from our recent community drama performance addressing gender-based violence. Art has the power to educate and inspire change. Thank you to everyone who attended and supported our message. 🎭',
      video: true,
      likes: 67,
      comments: 23,
      shares: 19
    }
  ]);

  return (
    <div className="grid lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2">
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex space-x-4">
            <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
            <div className="flex-1">
              <textarea
                placeholder="Share your thoughts with the KYN community..."
                className="w-full p-3 border border-gray-200 rounded-lg resize-none h-24 text-sm"
                maxLength={500}
              />
              <div className="flex items-center justify-between mt-3">
                <div className="flex space-x-4">
                  <button className="flex items-center space-x-2 text-gray-600 hover:text-green-600 cursor-pointer">
                    <i className="ri-image-line"></i>
                    <span className="text-sm">Photo</span>
                  </button>
                  <button className="flex items-center space-x-2 text-gray-600 hover:text-green-600 cursor-pointer">
                    <i className="ri-video-line"></i>
                    <span className="text-sm">Video</span>
                  </button>
                  <button className="flex items-center space-x-2 text-gray-600 hover:text-green-600 cursor-pointer">
                    <i className="ri-mic-line"></i>
                    <span className="text-sm">Audio</span>
                  </button>
                </div>
                <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-full text-sm font-medium transition-colors cursor-pointer whitespace-nowrap">
                  Share
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {posts.map(post => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="font-bold text-gray-900 mb-4">Active Members</h3>
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gray-200 rounded-full flex-shrink-0"></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">Member {i}</p>
                  <p className="text-xs text-gray-500">Online now</p>
                </div>
                <div className="w-3 h-3 bg-green-400 rounded-full"></div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="font-bold text-gray-900 mb-4">Trending Topics</h3>
          <div className="space-y-2">
            <div className="text-sm text-green-600 hover:text-green-700 cursor-pointer">#CulturalPreservation</div>
            <div className="text-sm text-green-600 hover:text-green-700 cursor-pointer">#YouthEmpowerment</div>
            <div className="text-sm text-green-600 hover:text-green-700 cursor-pointer">#PeaceBuildingUganda</div>
            <div className="text-sm text-green-600 hover:text-green-700 cursor-pointer">#KelikoTraditions</div>
            <div className="text-sm text-green-600 hover:text-green-700 cursor-pointer">#RefugeeVoices</div>
          </div>
        </div>
      </div>
    </div>
  );
}