'use client';

import { useState } from 'react';

interface PostCardProps {
  post: {
    id: number;
    author: string;
    avatar: string;
    time: string;
    content: string;
    image?: string;
    video?: boolean;
    likes: number;
    comments: number;
    shares: number;
  };
}

export default function PostCard({ post }: PostCardProps) {
  const [liked, setLiked] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes);

  const handleLike = () => {
    setLiked(!liked);
    setLikeCount(prev => liked ? prev - 1 : prev + 1);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <img 
            src={post.avatar} 
            alt={post.author}
            className="w-12 h-12 rounded-full object-cover object-top"
          />
          <div className="flex-1">
            <h4 className="font-semibold text-gray-900">{post.author}</h4>
            <p className="text-sm text-gray-500">{post.time}</p>
          </div>
          <button className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 cursor-pointer">
            <i className="ri-more-line"></i>
          </button>
        </div>

        <p className="text-gray-800 mb-4 leading-relaxed">{post.content}</p>

        {post.image && (
          <div className="mb-4 rounded-lg overflow-hidden">
            <img 
              src={post.image} 
              alt="Post content"
              className="w-full h-64 object-cover object-top"
            />
          </div>
        )}

        {post.video && (
          <div className="mb-4 rounded-lg overflow-hidden bg-gray-100">
            <div className="w-full h-64 flex items-center justify-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-green-700 transition-colors">
                <i className="ri-play-fill text-white text-2xl"></i>
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between text-gray-500 text-sm mb-4">
          <span>{likeCount} likes</span>
          <div className="flex space-x-4">
            <span>{post.comments} comments</span>
            <span>{post.shares} shares</span>
          </div>
        </div>

        <div className="flex items-center justify-between border-t border-gray-100 pt-3">
          <button 
            onClick={handleLike}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors cursor-pointer ${
              liked ? 'text-red-600' : 'text-gray-600 hover:text-red-600'
            }`}
          >
            <i className={`${liked ? 'ri-heart-fill' : 'ri-heart-line'}`}></i>
            <span className="text-sm">Like</span>
          </button>
          
          <button 
            onClick={() => setShowComments(!showComments)}
            className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:text-green-600 transition-colors cursor-pointer"
          >
            <i className="ri-chat-1-line"></i>
            <span className="text-sm">Comment</span>
          </button>
          
          <button className="flex items-center space-x-2 px-4 py-2 rounded-lg text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
            <i className="ri-share-line"></i>
            <span className="text-sm">Share</span>
          </button>
        </div>
      </div>

      {showComments && (
        <div className="border-t border-gray-100 p-6">
          <div className="flex space-x-3 mb-4">
            <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
            <div className="flex-1">
              <input
                type="text"
                placeholder="Write a comment..."
                className="w-full p-2 border border-gray-200 rounded-lg text-sm"
              />
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex space-x-3">
              <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
              <div className="flex-1">
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="font-medium text-sm text-gray-900">Mary Johnson</p>
                  <p className="text-sm text-gray-700">This is amazing work! Keep it up KYN family! 💪</p>
                </div>
                <div className="flex items-center space-x-4 mt-1">
                  <span className="text-xs text-gray-500">2h</span>
                  <button className="text-xs text-gray-500 hover:text-green-600 cursor-pointer">Like</button>
                  <button className="text-xs text-gray-500 hover:text-green-600 cursor-pointer">Reply</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}