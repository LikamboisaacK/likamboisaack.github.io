'use client';

import { useState } from 'react';

export default function MemberProfiles() {
  const [members] = useState([
    {
      id: 1,
      name: 'Sarah Kiden',
      role: 'Cultural Coordinator',
      location: 'Bidibidi Settlement',
      avatar: 'https://readdy.ai/api/search-image?query=Young%20African%20woman%20smiling%20portrait%20professional%20headshot%20natural%20lighting%20confident%20expression%20traditional%20cultural%20clothing%20colorful%20background%20South%20Sudan%20Uganda&width=150&height=150&seq=member-1&orientation=squarish',
      bio: 'Passionate about preserving Keliko traditions and teaching cultural practices to youth.',
      interests: ['Cultural Preservation', 'Traditional Music', 'Youth Mentoring'],
      joinedDate: 'March 2023',
      posts: 45
    },
    {
      id: 2,
      name: 'James Loku',
      role: 'Peace Ambassador',
      location: 'Imvepi Settlement',
      avatar: 'https://readdy.ai/api/search-image?query=Young%20African%20man%20smiling%20portrait%20professional%20headshot%20natural%20lighting%20confident%20expression%20casual%20clothing%20warm%20background%20South%20Sudan%20Uganda&width=150&height=150&seq=member-2&orientation=squarish',
      bio: 'Facilitating dialogue sessions and promoting peaceful coexistence among communities.',
      interests: ['Peacebuilding', 'Community Dialogue', 'Conflict Resolution'],
      joinedDate: 'January 2023',
      posts: 32
    },
    {
      id: 3,
      name: 'Grace Amara',
      role: 'Youth Leader',
      location: 'Rhino Camp',
      avatar: 'https://readdy.ai/api/search-image?query=Young%20African%20woman%20confident%20expression%20portrait%20professional%20headshot%20natural%20lighting%20bright%20smile%20traditional%20elements%20modern%20style%20South%20Sudan%20Uganda&width=150&height=150&seq=member-3&orientation=squarish',
      bio: 'Empowering young people through leadership training and advocacy programs.',
      interests: ['Leadership Development', 'Advocacy', 'Gender Equality'],
      joinedDate: 'February 2023',
      posts: 58
    },
    {
      id: 4,
      name: 'Peter Wani',
      role: 'Creative Arts Director',
      location: 'Bidibidi Settlement',
      avatar: 'https://readdy.ai/api/search-image?query=Young%20African%20man%20serious%20expression%20portrait%20professional%20headshot%20natural%20lighting%20determined%20look%20casual%20clothing%20warm%20background%20South%20Sudan%20Uganda&width=150&height=150&seq=member-4&orientation=squarish',
      bio: 'Using drama, poetry, and music to address social issues and inspire change.',
      interests: ['Drama', 'Poetry', 'Social Change', 'Community Theater'],
      joinedDate: 'April 2023',
      posts: 29
    },
    {
      id: 5,
      name: 'Rebecca Lado',
      role: 'Gender Advocate',
      location: 'Bidibidi Settlement',
      avatar: 'https://readdy.ai/api/search-image?query=Young%20African%20woman%20professional%20portrait%20confident%20smile%20natural%20lighting%20business%20casual%20clothing%20warm%20background%20South%20Sudan%20Uganda%20empowerment&width=150&height=150&seq=member-5&orientation=squarish',
      bio: 'Working to prevent gender-based violence and promote womens rights in our community.',
      interests: ['Gender Rights', 'Protection', 'Womens Empowerment'],
      joinedDate: 'May 2023',
      posts: 23
    },
    {
      id: 6,
      name: 'David Konga',
      role: 'Tech Coordinator',
      location: 'Kampala',
      avatar: 'https://readdy.ai/api/search-image?query=Young%20African%20man%20portrait%20professional%20headshot%20modern%20style%20confident%20expression%20smart%20casual%20clothing%20technology%20background%20South%20Sudan%20Uganda&width=150&height=150&seq=member-6&orientation=squarish',
      bio: 'Connecting our community through digital platforms and teaching digital literacy.',
      interests: ['Technology', 'Digital Literacy', 'Online Community'],
      joinedDate: 'June 2023',
      posts: 18
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');

  const filteredMembers = members.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.bio.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = selectedRole === 'all' || member.role === selectedRole;
    return matchesSearch && matchesRole;
  });

  const roles = ['all', ...Array.from(new Set(members.map(m => m.role)))];

  return (
    <div>
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              <input
                type="text"
                placeholder="Search members..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm"
              />
            </div>
          </div>
          <div className="md:w-64">
            <select
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value)}
              className="w-full p-2 pr-8 border border-gray-200 rounded-lg text-sm"
            >
              {roles.map(role => (
                <option key={role} value={role}>
                  {role === 'all' ? 'All Roles' : role}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMembers.map(member => (
          <div key={member.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-6">
              <div className="text-center mb-4">
                <img 
                  src={member.avatar} 
                  alt={member.name}
                  className="w-20 h-20 rounded-full mx-auto mb-3 object-cover object-top"
                />
                <h3 className="font-bold text-gray-900 mb-1">{member.name}</h3>
                <p className="text-sm text-green-600 font-medium mb-1">{member.role}</p>
                <p className="text-xs text-gray-500">{member.location}</p>
              </div>

              <p className="text-sm text-gray-600 text-center mb-4 leading-relaxed">
                {member.bio}
              </p>

              <div className="mb-4">
                <h4 className="text-xs font-semibold text-gray-900 mb-2">Interests</h4>
                <div className="flex flex-wrap gap-1">
                  {member.interests.map((interest, index) => (
                    <span 
                      key={index}
                      className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs"
                    >
                      {interest}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                <span>Joined {member.joinedDate}</span>
                <span>{member.posts} posts</span>
              </div>

              <div className="flex space-x-2">
                <button className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap">
                  Connect
                </button>
                <button className="flex-1 border border-gray-200 hover:border-green-600 text-gray-600 hover:text-green-600 py-2 px-3 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap">
                  Message
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredMembers.length === 0 && (
        <div className="text-center py-12">
          <i className="ri-user-search-line text-4xl text-gray-300 mb-4"></i>
          <p className="text-gray-500">No members found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}