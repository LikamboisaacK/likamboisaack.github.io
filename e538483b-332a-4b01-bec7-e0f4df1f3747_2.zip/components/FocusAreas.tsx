'use client';

export default function FocusAreas() {
  const focusAreas = [
    {
      icon: 'ri-peace-line',
      title: 'Peacebuilding & Dialogue',
      description: 'Promoting peaceful coexistence through youth forums and inter-community discussions.',
      color: 'bg-blue-100 text-blue-600'
    },
    {
      icon: 'ri-music-line',
      title: 'Cultural Preservation',
      description: 'Safeguarding and promoting Keliko language, music (Úngó), dance, and oral history.',
      color: 'bg-purple-100 text-purple-600'
    },
    {
      icon: 'ri-user-star-line',
      title: 'Youth Empowerment',
      description: 'Strengthening youth leadership, volunteerism, and advocacy.',
      color: 'bg-green-100 text-green-600'
    },
    {
      icon: 'ri-shield-user-line',
      title: 'Gender and Protection',
      description: 'Raising awareness on gender-based violence and advancing social justice.',
      color: 'bg-red-100 text-red-600'
    },
    {
      icon: 'ri-palette-line',
      title: 'Creative Arts for Change',
      description: 'Using drama, poetry, and music to inspire action and amplify youth voices.',
      color: 'bg-orange-100 text-orange-600'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Core Focus Areas</h2>
            <div className="w-24 h-1 bg-green-600 mx-auto mb-8"></div>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our comprehensive approach addresses multiple aspects of youth development and community building.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {focusAreas.map((area, index) => (
              <div key={index} className="bg-gray-50 p-8 rounded-lg hover:shadow-md transition-shadow">
                <div className={`w-16 h-16 ${area.color} rounded-full flex items-center justify-center mb-6`}>
                  <i className={`${area.icon} text-2xl`}></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{area.title}</h3>
                <p className="text-gray-600 leading-relaxed">{area.description}</p>
              </div>
            ))}
          </div>

          <div className="bg-green-50 rounded-2xl p-8 md:p-12">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">Our Approach</h3>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  KYN uses a youth-to-youth model built on participation, cultural identity, and grassroots mobilization. Through inclusive cultural forums and artistic expressions, the Network fosters belonging, resilience, and civic agency among displaced youth.
                </p>
                <div className="bg-white p-6 rounded-lg">
                  <h4 className="font-bold text-gray-900 mb-3">Why We Matter</h4>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    In contexts of forced displacement, youth are often marginalized and stripped of cultural anchors. KYN fills this gap by restoring identity, encouraging leadership, and building peace from the ground up—ensuring that young people are not just recipients of aid, but key actors in transformation.
                  </p>
                </div>
              </div>
              
              <div className="relative">
                <img 
                  src="https://readdy.ai/api/search-image?query=Young%20African%20people%20participating%20in%20community%20dialogue%20session%2C%20sitting%20in%20circle%20outdoors%2C%20diverse%20group%20of%20youth%20discussing%2C%20peaceful%20community%20meeting%2C%20natural%20lighting%2C%20grassroots%20organizing%2C%20youth%20leadership%20development%2C%20collaborative%20discussion%20in%20refugee%20settlement%20setting&width=600&height=400&seq=kyn-dialogue-1&orientation=landscape"
                  alt="Youth Dialogue"
                  className="w-full h-auto rounded-lg shadow-lg object-top"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}