'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
                  <i className="ri-community-line text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="font-['Pacifico'] text-xl text-green-400">KYN</h3>
                  <p className="text-xs text-gray-400">Youth Network</p>
                </div>
              </div>
              <p className="text-gray-300 mb-4 leading-relaxed">
                Empowering Keliko youth through culture, dialogue, and action in humanitarian settings.
              </p>
              <div className="flex space-x-3">
                <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-green-600 transition-colors cursor-pointer">
                  <i className="ri-facebook-line text-white"></i>
                </div>
                <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-green-600 transition-colors cursor-pointer">
                  <i className="ri-twitter-line text-white"></i>
                </div>
                <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-green-600 transition-colors cursor-pointer">
                  <i className="ri-instagram-line text-white"></i>
                </div>
                <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-green-600 transition-colors cursor-pointer">
                  <i className="ri-youtube-line text-white"></i>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-bold mb-4 text-white">Quick Links</h4>
              <div className="space-y-2">
                <Link href="/about" className="block text-gray-300 hover:text-green-400 transition-colors">About Us</Link>
                <Link href="/community" className="block text-gray-300 hover:text-green-400 transition-colors">Community</Link>
                <Link href="/media" className="block text-gray-300 hover:text-green-400 transition-colors">Media Hub</Link>
                <Link href="/events" className="block text-gray-300 hover:text-green-400 transition-colors">Events</Link>
                <Link href="/volunteer" className="block text-gray-300 hover:text-green-400 transition-colors">Volunteer</Link>
              </div>
            </div>
            
            <div>
              <h4 className="font-bold mb-4 text-white">Focus Areas</h4>
              <div className="space-y-2">
                <p className="text-gray-300 text-sm">Peacebuilding & Dialogue</p>
                <p className="text-gray-300 text-sm">Cultural Preservation</p>
                <p className="text-gray-300 text-sm">Youth Empowerment</p>
                <p className="text-gray-300 text-sm">Gender & Protection</p>
                <p className="text-gray-300 text-sm">Creative Arts</p>
              </div>
            </div>
            
            <div>
              <h4 className="font-bold mb-4 text-white">Contact Info</h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 flex items-center justify-center">
                    <i className="ri-phone-line text-green-400"></i>
                  </div>
                  <div>
                    <p className="text-gray-300 text-sm">+256 774 652 401</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 flex items-center justify-center">
                    <i className="ri-mail-line text-green-400"></i>
                  </div>
                  <div>
                    <p className="text-gray-300 text-sm">kynetwork.morobo@gmail.com</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 flex items-center justify-center mt-1">
                    <i className="ri-map-pin-line text-green-400"></i>
                  </div>
                  <div>
                    <p className="text-gray-300 text-sm">Bidibidi Refugee Settlement</p>
                    <p className="text-gray-300 text-sm">Morobo County, Central Equatoria</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-gray-400 text-sm">
              © 2024 Keliko Youth Network (KYN). All rights reserved. "Youth Empowerment through Culture, Dialogue, and Action"
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}