'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppChat from '@/components/WhatsAppChat';
import CommunityFeed from '@/components/community/CommunityFeed';
import MemberProfiles from '@/components/community/MemberProfiles';

export default function CommunityPage() {
  const [activeTab, setActiveTab] = useState('feed');

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">KYN Community</h1>
            <p className="text-lg text-gray-600">Connect, share, and engage with fellow Keliko youth</p>
          </div>

          <div className="flex justify-center mb-8">
            <div className="bg-white p-1 rounded-full shadow-sm">
              <button
                onClick={() => setActiveTab('feed')}
                className={`px-6 py-2 rounded-full font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'feed' 
                    ? 'bg-green-600 text-white' 
                    : 'text-gray-600 hover:text-green-600'
                }`}
              >
                Community Feed
              </button>
              <button
                onClick={() => setActiveTab('members')}
                className={`px-6 py-2 rounded-full font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'members' 
                    ? 'bg-green-600 text-white' 
                    : 'text-gray-600 hover:text-green-600'
                }`}
              >
                Members
              </button>
            </div>
          </div>

          {activeTab === 'feed' && <CommunityFeed />}
          {activeTab === 'members' && <MemberProfiles />}
        </div>
      </div>

      <WhatsAppChat />
      <Footer />
    </div>
  );
}