'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppChat from '@/components/WhatsAppChat';
import MediaGallery from '@/components/media/MediaGallery';
import AudioPlayer from '@/components/media/AudioPlayer';
import VideoPlayer from '@/components/media/VideoPlayer';

export default function MediaPage() {
  const [activeTab, setActiveTab] = useState('all');

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Media Hub</h1>
            <p className="text-lg text-gray-600">Share and discover cultural content from our community</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Upload your video, audio, or photo..."
                  className="w-full p-4 border-2 border-dashed border-gray-200 rounded-lg text-gray-500 cursor-pointer"
                />
              </div>
              <div className="flex space-x-2">
                <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                  <i className="ri-video-add-line"></i>
                  <span>Video</span>
                </button>
                <button className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap">
                  <i className="ri-mic-line"></i>
                  <span>Audio</span>
                </button>
                <button className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors cursor-pointer whitespace-nowrap">
                  <i className="ri-image-add-line"></i>
                  <span>Photo</span>
                </button>
              </div>
            </div>
          </div>

          <div className="flex justify-center mb-8">
            <div className="bg-white p-1 rounded-full shadow-sm">
              {['all', 'videos', 'audio', 'photos'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-6 py-2 rounded-full font-medium transition-colors capitalize whitespace-nowrap cursor-pointer ${
                    activeTab === tab 
                      ? 'bg-green-600 text-white' 
                      : 'text-gray-600 hover:text-green-600'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {activeTab === 'all' && <MediaGallery />}
          {activeTab === 'videos' && <VideoPlayer />}
          {activeTab === 'audio' && <AudioPlayer />}
          {activeTab === 'photos' && <MediaGallery filter="photos" />}
        </div>
      </div>

      <WhatsAppChat />
      <Footer />
    </div>
  );
}